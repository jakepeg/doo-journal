import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import { UserProfile, JournalEntry } from '../backend';
import { Principal } from '@dfinity/principal';
import { toast } from 'sonner';

export function useGetCallerUserProfile() {
  console.log('[DEBUG] useGetCallerUserProfile: Hook called');
  
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      console.log('[DEBUG] useGetCallerUserProfile: Query function called', {
        actor: !!actor,
        actorFetching
      });
      
      if (!actor) {
        console.log('[DEBUG] useGetCallerUserProfile: No actor available');
        throw new Error('Actor not available');
      }
      
      try {
        console.log('[DEBUG] useGetCallerUserProfile: Calling getCallerUserProfile');
        const result = await actor.getCallerUserProfile();
        console.log('[DEBUG] useGetCallerUserProfile: Result received', {
          hasProfile: !!result,
          profileName: result?.name
        });
        return result;
      } catch (error) {
        console.error('[DEBUG] useGetCallerUserProfile: Error fetching user profile:', error);
        // Return null instead of throwing to prevent infinite loading
        return null;
      }
    },
    enabled: !!actor && !actorFetching,
    retry: 1, // Only retry once to prevent infinite loading
    staleTime: 5 * 60 * 1000, // 5 minutes
    // Ensure the query completes even if there's an error
    throwOnError: false,
  });

  // Improved loading state logic to prevent infinite loading
  const isActuallyLoading = !actor || actorFetching || (!!actor && !actorFetching && query.isLoading && !query.isFetched);
  
  // Only consider it fetched if we have an actor, it's not fetching, and the query has completed
  const isActuallyFetched = !!actor && !actorFetching && (query.isFetched || query.isError);

  console.log('[DEBUG] useGetCallerUserProfile: State', {
    isLoading: isActuallyLoading,
    isFetched: isActuallyFetched,
    hasData: !!query.data,
    error: query.error?.message,
    queryState: {
      isLoading: query.isLoading,
      isFetched: query.isFetched,
      isError: query.isError
    }
  });

  return {
    ...query,
    isLoading: isActuallyLoading,
    isFetched: isActuallyFetched,
  };
}

export function useSaveUserProfile() {
  console.log('[DEBUG] useSaveUserProfile: Hook called');
  
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      console.log('[DEBUG] useSaveUserProfile: Mutation called', {
        profile,
        hasActor: !!actor
      });
      
      if (!actor) {
        console.error('[DEBUG] useSaveUserProfile: No actor available');
        throw new Error('Actor not available');
      }
      
      try {
        const result = await actor.saveCallerUserProfile(profile);
        console.log('[DEBUG] useSaveUserProfile: Profile saved successfully');
        return result;
      } catch (error) {
        console.error('[DEBUG] useSaveUserProfile: Error saving profile:', error);
        throw error;
      }
    },
    onSuccess: () => {
      console.log('[DEBUG] useSaveUserProfile: Mutation success, invalidating queries');
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
      queryClient.invalidateQueries({ queryKey: ['ownHomepage'] });
      toast.success('Profile saved successfully!');
    },
    onError: (error) => {
      console.error('[DEBUG] useSaveUserProfile: Mutation error:', error);
      toast.error('Failed to save profile: ' + error.message);
    },
  });
}

export function useGetOwnHomepage() {
  console.log('[DEBUG] useGetOwnHomepage: Hook called');
  
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<{ profile?: UserProfile; entries: JournalEntry[] }>({
    queryKey: ['ownHomepage'],
    queryFn: async () => {
      console.log('[DEBUG] useGetOwnHomepage: Query function called', {
        actor: !!actor,
        actorFetching
      });
      
      if (!actor) {
        console.error('[DEBUG] useGetOwnHomepage: No actor available');
        throw new Error('Actor not available');
      }
      
      try {
        const result = await actor.getOwnHomepage();
        console.log('[DEBUG] useGetOwnHomepage: Result received', {
          hasProfile: !!result.profile,
          entriesCount: result.entries.length
        });
        return result;
      } catch (error) {
        console.error('[DEBUG] useGetOwnHomepage: Error:', error);
        throw error;
      }
    },
    enabled: !!actor && !actorFetching,
    staleTime: 2 * 60 * 1000, // 2 minutes
    retry: 2,
  });
}

export function useGetUserHomepage(user: Principal) {
  console.log('[DEBUG] useGetUserHomepage: Hook called', {
    user: user.toString()
  });
  
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<{ profile?: UserProfile; publicEntries: JournalEntry[] }>({
    queryKey: ['userHomepage', user.toString()],
    queryFn: async () => {
      console.log('[DEBUG] useGetUserHomepage: Query function called', {
        actor: !!actor,
        user: user.toString()
      });
      
      if (!actor) {
        console.error('[DEBUG] useGetUserHomepage: No actor available');
        throw new Error('Actor not available');
      }
      
      try {
        const result = await actor.getUserHomepage(user);
        console.log('[DEBUG] useGetUserHomepage: Result received', {
          hasProfile: !!result.profile,
          publicEntriesCount: result.publicEntries.length
        });
        return result;
      } catch (error) {
        console.error('[DEBUG] useGetUserHomepage: Error:', error);
        throw error;
      }
    },
    // Enable this query even without authentication for public profiles
    enabled: !!actor && !!user,
    staleTime: 2 * 60 * 1000, // 2 minutes
    retry: 3, // Retry failed requests
  });
}

export function useGetJournalEntry(user: Principal, entryId: string) {
  console.log('[DEBUG] useGetJournalEntry: Hook called', {
    user: user.toString(),
    entryId
  });
  
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<JournalEntry | null>({
    queryKey: ['journalEntry', user.toString(), entryId],
    queryFn: async () => {
      console.log('[DEBUG] useGetJournalEntry: Query function called', {
        actor: !!actor,
        user: user.toString(),
        entryId
      });
      
      if (!actor) {
        console.error('[DEBUG] useGetJournalEntry: No actor available');
        throw new Error('Actor not available');
      }
      
      try {
        const result = await actor.getJournalEntryById(user, entryId);
        console.log('[DEBUG] useGetJournalEntry: Result received', {
          hasEntry: !!result,
          entryTitle: result?.title
        });
        return result;
      } catch (error) {
        console.error('[DEBUG] useGetJournalEntry: Error:', error);
        throw error;
      }
    },
    // Enable this query even without authentication for public entries
    enabled: !!actor && !!user && !!entryId,
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 2,
  });
}

export function useGetPublicJournalEntryWithProfile(user: Principal, entryId: string) {
  console.log('[DEBUG] useGetPublicJournalEntryWithProfile: Hook called', {
    user: user.toString(),
    entryId
  });
  
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<{ entry: JournalEntry; profile: UserProfile } | null>({
    queryKey: ['publicJournalEntryWithProfile', user.toString(), entryId],
    queryFn: async () => {
      console.log('[DEBUG] useGetPublicJournalEntryWithProfile: Query function called', {
        actor: !!actor,
        user: user.toString(),
        entryId
      });
      
      if (!actor) {
        console.error('[DEBUG] useGetPublicJournalEntryWithProfile: No actor available');
        throw new Error('Actor not available');
      }
      
      try {
        const result = await actor.getPublicJournalEntryWithProfile(user, entryId);
        console.log('[DEBUG] useGetPublicJournalEntryWithProfile: Result received', {
          hasResult: !!result,
          entryTitle: result?.entry.title,
          profileName: result?.profile.name
        });
        return result;
      } catch (error) {
        console.error('[DEBUG] useGetPublicJournalEntryWithProfile: Error:', error);
        throw error;
      }
    },
    // Enable this query even without authentication for public entries
    enabled: !!actor && !!user && !!entryId,
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 3,
  });
}

export function useCreateJournalEntry() {
  console.log('[DEBUG] useCreateJournalEntry: Hook called');
  
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ title, content, isPublic, date, imagePath }: { title: string; content: string; isPublic: boolean; date: bigint; imagePath: string | null }) => {
      console.log('[DEBUG] useCreateJournalEntry: Mutation called', {
        title,
        contentLength: content.length,
        isPublic,
        date: date.toString(),
        hasImagePath: !!imagePath,
        hasActor: !!actor
      });
      
      if (!actor) {
        console.error('[DEBUG] useCreateJournalEntry: No actor available');
        throw new Error('Actor not available');
      }
      
      try {
        const result = await actor.createJournalEntry(title, content, isPublic, date, imagePath);
        console.log('[DEBUG] useCreateJournalEntry: Entry created successfully', { entryId: result });
        return result;
      } catch (error) {
        console.error('[DEBUG] useCreateJournalEntry: Error creating entry:', error);
        throw error;
      }
    },
    onSuccess: () => {
      console.log('[DEBUG] useCreateJournalEntry: Mutation success, invalidating queries');
      queryClient.invalidateQueries({ queryKey: ['ownHomepage'] });
      queryClient.invalidateQueries({ queryKey: ['allJournalEntries'] });
      toast.success('Journal entry created!');
    },
    onError: (error) => {
      console.error('[DEBUG] useCreateJournalEntry: Mutation error:', error);
      toast.error('Failed to create entry: ' + error.message);
    },
  });
}

export function useUpdateJournalEntry() {
  console.log('[DEBUG] useUpdateJournalEntry: Hook called');
  
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ entryId, title, content, isPublic, date, imagePath }: { entryId: string; title: string; content: string; isPublic: boolean; date: bigint; imagePath: string | null }) => {
      console.log('[DEBUG] useUpdateJournalEntry: Mutation called', {
        entryId,
        title,
        contentLength: content.length,
        isPublic,
        date: date.toString(),
        hasImagePath: !!imagePath,
        hasActor: !!actor
      });
      
      if (!actor) {
        console.error('[DEBUG] useUpdateJournalEntry: No actor available');
        throw new Error('Actor not available');
      }
      
      try {
        const result = await actor.updateJournalEntry(entryId, title, content, isPublic, date, imagePath);
        console.log('[DEBUG] useUpdateJournalEntry: Entry updated successfully');
        return result;
      } catch (error) {
        console.error('[DEBUG] useUpdateJournalEntry: Error updating entry:', error);
        throw error;
      }
    },
    onSuccess: (_, variables) => {
      console.log('[DEBUG] useUpdateJournalEntry: Mutation success, invalidating queries');
      queryClient.invalidateQueries({ queryKey: ['ownHomepage'] });
      queryClient.invalidateQueries({ queryKey: ['allJournalEntries'] });
      queryClient.invalidateQueries({ queryKey: ['journalEntry'] });
      toast.success('Journal entry updated!');
    },
    onError: (error) => {
      console.error('[DEBUG] useUpdateJournalEntry: Mutation error:', error);
      toast.error('Failed to update entry: ' + error.message);
    },
  });
}

export function useDeleteJournalEntry() {
  console.log('[DEBUG] useDeleteJournalEntry: Hook called');
  
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (entryId: string) => {
      console.log('[DEBUG] useDeleteJournalEntry: Mutation called', {
        entryId,
        hasActor: !!actor
      });
      
      if (!actor) {
        console.error('[DEBUG] useDeleteJournalEntry: No actor available');
        throw new Error('Actor not available');
      }
      
      try {
        const result = await actor.deleteJournalEntry(entryId);
        console.log('[DEBUG] useDeleteJournalEntry: Entry deleted successfully');
        return result;
      } catch (error) {
        console.error('[DEBUG] useDeleteJournalEntry: Error deleting entry:', error);
        throw error;
      }
    },
    onSuccess: () => {
      console.log('[DEBUG] useDeleteJournalEntry: Mutation success, invalidating queries');
      queryClient.invalidateQueries({ queryKey: ['ownHomepage'] });
      queryClient.invalidateQueries({ queryKey: ['allJournalEntries'] });
      queryClient.invalidateQueries({ queryKey: ['journalEntry'] });
      toast.success('Journal entry deleted!');
    },
    onError: (error) => {
      console.error('[DEBUG] useDeleteJournalEntry: Mutation error:', error);
      toast.error('Failed to delete entry: ' + error.message);
    },
  });
}

export function useGetAllJournalEntries() {
  console.log('[DEBUG] useGetAllJournalEntries: Hook called');
  
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<JournalEntry[]>({
    queryKey: ['allJournalEntries'],
    queryFn: async () => {
      console.log('[DEBUG] useGetAllJournalEntries: Query function called', {
        actor: !!actor,
        actorFetching
      });
      
      if (!actor) {
        console.error('[DEBUG] useGetAllJournalEntries: No actor available');
        throw new Error('Actor not available');
      }
      
      try {
        const result = await actor.getAllJournalEntries();
        console.log('[DEBUG] useGetAllJournalEntries: Result received', {
          entriesCount: result.length
        });
        return result;
      } catch (error) {
        console.error('[DEBUG] useGetAllJournalEntries: Error:', error);
        throw error;
      }
    },
    enabled: !!actor && !actorFetching,
    staleTime: 2 * 60 * 1000, // 2 minutes
    retry: 2,
  });
}
