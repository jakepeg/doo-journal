import { useGetUserHomepage } from '../hooks/useQueries';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Globe, Sparkles, Image as ImageIcon } from 'lucide-react';
import { useFileUrl } from '../blob-storage/FileStorage';
import { Principal } from '@dfinity/principal';
import { useState, useEffect } from 'react';
import { useActor } from '../hooks/useActor';
import DooLogo from './DooLogo';

interface PublicHomepageProps {
  user: Principal;
  onBackToLogin: () => void;
}

export default function PublicHomepage({ user, onBackToLogin }: PublicHomepageProps) {
  const { data: homepage, isLoading } = useGetUserHomepage(user);
  const [coverImageError, setCoverImageError] = useState(false);
  const [profileImageError, setProfileImageError] = useState(false);
  const { actor } = useActor();
  
  // Try to get image URLs using the file storage system
  const { data: profilePictureUrl } = useFileUrl(homepage?.profile?.profilePicture || '');
  const { data: coverImageUrl } = useFileUrl(homepage?.profile?.coverImage || '');
  
  // Fallback: construct direct URLs if the file storage URLs don't work
  const [fallbackProfileUrl, setFallbackProfileUrl] = useState<string>('');
  const [fallbackCoverUrl, setFallbackCoverUrl] = useState<string>('');

  useEffect(() => {
    // If we have profile picture path but no URL from file storage, try to construct a direct URL
    if (homepage?.profile?.profilePicture && !profilePictureUrl && !profileImageError) {
      // Try to construct a direct URL to the file storage system
      const directUrl = `${window.location.origin}/api/files/${homepage.profile.profilePicture}`;
      setFallbackProfileUrl(directUrl);
    }
  }, [homepage?.profile?.profilePicture, profilePictureUrl, profileImageError]);

  useEffect(() => {
    // If we have cover image path but no URL from file storage, try to construct a direct URL
    if (homepage?.profile?.coverImage && !coverImageUrl && !coverImageError) {
      // Try to construct a direct URL to the file storage system
      const directUrl = `${window.location.origin}/api/files/${homepage.profile.coverImage}`;
      setFallbackCoverUrl(directUrl);
    }
  }, [homepage?.profile?.coverImage, coverImageUrl, coverImageError]);

  const handleCoverImageError = () => {
    setCoverImageError(true);
    setFallbackCoverUrl('');
  };

  const handleProfileImageError = () => {
    setProfileImageError(true);
    setFallbackProfileUrl('');
  };

  const formatDate = (timestamp: bigint) => {
    return new Date(Number(timestamp) / 1000000).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const truncateContent = (content: string, maxLength: number = 200) => {
    // Remove markdown image syntax for display
    const contentWithoutImages = content.replace(/!\[.*?\]\(.*?\)/g, '');
    if (contentWithoutImages.length <= maxLength) return contentWithoutImages;
    return contentWithoutImages.substring(0, maxLength) + '...';
  };

  const extractFirstImageUrl = (content: string): string | null => {
    // Extract the first image URL from markdown format: ![alt](url)
    const imageMatch = content.match(/!\[.*?\]\((.*?)\)/);
    return imageMatch ? imageMatch[1] : null;
  };

  const handleStartJournal = () => {
    // Clear URL parameters and go to landing page
    window.location.href = window.location.origin;
  };

  if (isLoading) {
    return (
      <div className="flex flex-col flex-1">
        {/* Header */}
        <header className="bg-white/80 backdrop-blur-sm border-b border-purple-200 sticky top-0 z-40">
          <div className="container mx-auto px-4 py-4 max-w-[1024px]">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <DooLogo width={40} height={40} />
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  Public Journal
                </h1>
              </div>
              <Button
                onClick={handleStartJournal}
                className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white shadow-lg"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Start Your Own Journal
              </Button>
            </div>
          </div>
        </header>
        
        <div className="flex items-center justify-center flex-1">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading journal...</p>
          </div>
        </div>
      </div>
    );
  }

  const profile = homepage?.profile;
  const entries = homepage?.publicEntries || [];

  // Determine which image URLs to use
  const finalProfilePictureUrl = profilePictureUrl || fallbackProfileUrl;
  const finalCoverImageUrl = coverImageUrl || fallbackCoverUrl;

  return (
    <div className="flex flex-col flex-1">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-purple-200 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 max-w-[1024px]">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <DooLogo width={40} height={40} />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                {profile?.name ? `${profile.name}'s Journal` : 'Public Journal'}
              </h1>
            </div>
            <Button
              onClick={handleStartJournal}
              className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white shadow-lg"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Start Your Own Journal
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 max-w-[1024px] flex-1 mb-8">
        {/* Profile Section */}
        {profile ? (
          <Card className="mt-8 mb-8 border-0 shadow-xl bg-white/80 backdrop-blur-sm overflow-hidden">
            <div className="relative">
              {finalCoverImageUrl && !coverImageError ? (
                <div className="h-48 bg-gradient-to-r from-purple-400 to-blue-400 relative">
                  <img 
                    src={finalCoverImageUrl} 
                    alt="Cover" 
                    className="w-full h-full object-cover" 
                    onError={handleCoverImageError}
                    onLoad={() => setCoverImageError(false)}
                    crossOrigin="anonymous"
                  />
                  <div className="absolute inset-0 bg-black/20"></div>
                </div>
              ) : (
                <div className="h-48 bg-gradient-to-r from-purple-400 to-blue-400 relative">
                  <div className="absolute inset-0 bg-black/20"></div>
                  {(coverImageError || (profile.coverImage && !finalCoverImageUrl)) && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-white/80 text-center">
                        <ImageIcon className="w-12 h-12 mx-auto mb-2 opacity-60" />
                        <p className="text-sm">Cover image unavailable</p>
                      </div>
                    </div>
                  )}
                </div>
              )}
              
              {/* Profile Picture positioned to overlap cover image */}
              <div className="absolute left-6 -bottom-10">
                <Avatar className="w-20 h-20 border-4 border-white shadow-lg">
                  {finalProfilePictureUrl && !profileImageError ? (
                    <AvatarImage 
                      src={finalProfilePictureUrl} 
                      onError={handleProfileImageError}
                      crossOrigin="anonymous"
                    />
                  ) : null}
                  <AvatarFallback className="bg-gradient-to-br from-purple-400 to-blue-400 text-white text-2xl font-bold">
                    {profile.name?.charAt(0).toUpperCase() || '?'}
                  </AvatarFallback>
                </Avatar>
              </div>
            </div>
            
            <CardContent className="px-6 pt-12">
              <div className="ml-0">
                <h2 className="text-3xl font-bold text-gray-900 mb-2">
                  {profile.name}
                </h2>
                {profile.bio && (
                  <p className="text-gray-600 text-lg mb-4">{profile.bio}</p>
                )}
                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <span>{entries.length} public entries</span>
                  <Badge variant="outline" className="text-xs">
                    <Globe className="w-3 h-3 mr-1" />
                    Public Profile
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="mt-8 mb-8 border-0 shadow-xl bg-white/80 backdrop-blur-sm">
            <CardContent className="p-12 text-center">
              <DooLogo width={64} height={64} className="mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-700 mb-2">Anonymous Writer</h2>
              <p className="text-gray-600">This user hasn't set up their profile yet.</p>
            </CardContent>
          </Card>
        )}

        {/* Public Journal Entries Section */}
        <div className="mb-6">
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Public Journal Entries</h3>
          <p className="text-gray-600">Sharing thoughts and adventures with the world ✨</p>
        </div>

        {entries.length === 0 ? (
          <Card className="border-2 border-dashed border-purple-200 bg-purple-50/50 mb-8">
            <CardContent className="p-12 text-center">
              <Globe className="w-16 h-16 text-purple-400 mx-auto mb-4" />
              <h4 className="text-xl font-semibold text-gray-700 mb-2">No Public Entries Yet</h4>
              <p className="text-gray-600 mb-6">
                This writer hasn't shared any public journal entries yet. Check back later!
              </p>
              <Button
                onClick={handleStartJournal}
                className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white shadow-lg"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Start Your Own Journal
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6 mb-8">
            {entries
              .sort((a, b) => Number(b.timestamp) - Number(a.timestamp))
              .map((entry) => {
                const firstImageUrl = extractFirstImageUrl(entry.content);
                
                return (
                  <Card key={entry.id} className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-xl font-bold text-gray-900 mb-2">
                            {entry.title}
                          </CardTitle>
                          <div className="flex items-center space-x-3">
                            <span className="text-sm text-gray-500">
                              {formatDate(entry.timestamp)}
                            </span>
                            <Badge variant="default" className="text-xs">
                              <Globe className="w-3 h-3 mr-1" />
                              Public
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="flex gap-4">
                        {/* Image thumbnail */}
                        {firstImageUrl && (
                          <div className="flex-shrink-0">
                            <img 
                              src={firstImageUrl} 
                              alt="Entry preview" 
                              className="w-20 h-20 object-cover rounded-lg shadow-sm border border-gray-200"
                              onError={(e) => {
                                // Hide image if it fails to load
                                e.currentTarget.style.display = 'none';
                              }}
                              crossOrigin="anonymous"
                            />
                          </div>
                        )}
                        
                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                            {truncateContent(entry.content)}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
          </div>
        )}
      </main>
    </div>
  );
}
