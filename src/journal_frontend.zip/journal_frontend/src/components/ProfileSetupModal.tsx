import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { useSaveUserProfile } from '../hooks/useQueries';
import { useFileUpload, useFileUrl } from '../blob-storage/FileStorage';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Camera, Upload, Sparkles, X } from 'lucide-react';
import { toast } from 'sonner';

interface ProfileSetupModalProps {
  onClose: () => void;
}

export default function ProfileSetupModal({ onClose }: ProfileSetupModalProps) {
  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [profilePicturePath, setProfilePicturePath] = useState<string>('');
  const [coverImagePath, setCoverImagePath] = useState<string>('');
  
  const { mutate: saveProfile, isPending: isSaving } = useSaveUserProfile();
  const { uploadFile, isUploading } = useFileUpload();
  
  const { data: profilePictureUrl } = useFileUrl(profilePicturePath);
  const { data: coverImageUrl } = useFileUrl(coverImagePath);

  const handleProfilePictureUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file');
      return;
    }

    try {
      const path = `profile-pictures/${Date.now()}-${file.name}`;
      const result = await uploadFile(path, file);
      setProfilePicturePath(result.path);
      toast.success('Profile picture uploaded!');
    } catch (error) {
      toast.error('Failed to upload profile picture');
    }
  };

  const handleCoverImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file');
      return;
    }

    try {
      const path = `cover-images/${Date.now()}-${file.name}`;
      const result = await uploadFile(path, file);
      setCoverImagePath(result.path);
      toast.success('Cover image uploaded!');
    } catch (error) {
      toast.error('Failed to upload cover image');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast.error('Please enter your name');
      return;
    }

    saveProfile({
      name: name.trim(),
      bio: bio.trim(),
      profilePicture: profilePicturePath || undefined,
      coverImage: coverImagePath || undefined,
    }, {
      onSuccess: onClose,
    });
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md bg-gradient-to-br from-purple-50 to-blue-50 border-0 shadow-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent flex items-center justify-center gap-2">
            <Sparkles className="w-6 h-6 text-purple-500" />
            Create Your Profile
            <Sparkles className="w-6 h-6 text-blue-500" />
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="text-center">
            <div className="relative inline-block">
              <Avatar className="w-24 h-24 border-4 border-white shadow-lg">
                <AvatarImage src={profilePictureUrl} />
                <AvatarFallback className="bg-gradient-to-br from-purple-400 to-blue-400 text-white text-2xl font-bold">
                  {name.charAt(0).toUpperCase() || '?'}
                </AvatarFallback>
              </Avatar>
              <label className="absolute -bottom-2 -right-2 bg-white rounded-full p-2 shadow-lg cursor-pointer hover:bg-gray-50 transition-colors">
                <Camera className="w-4 h-4 text-gray-600" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleProfilePictureUpload}
                  className="hidden"
                  disabled={isUploading}
                />
              </label>
              {profilePicturePath && (
                <button
                  type="button"
                  onClick={() => setProfilePicturePath('')}
                  className="absolute -top-2 -left-2 bg-red-500 rounded-full p-1 shadow-lg hover:bg-red-600 transition-colors"
                >
                  <X className="w-3 h-3 text-white" />
                </button>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="name" className="text-sm font-semibold text-gray-700">
              What's your name? ✨
            </Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your first name or nickname"
              className="border-2 border-purple-200 focus:border-purple-400 rounded-lg"
              maxLength={50}
            />
            <p className="text-xs text-gray-500">{name.length}/50 characters</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio" className="text-sm font-semibold text-gray-700">
              Tell us about yourself! 🌟
            </Label>
            <Textarea
              id="bio"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="I love to write about adventures, dreams, and magical moments..."
              className="border-2 border-purple-200 focus:border-purple-400 rounded-lg min-h-[80px]"
              maxLength={200}
            />
            <p className="text-xs text-gray-500">{bio.length}/200 characters</p>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-semibold text-gray-700">
              Cover Image (Optional) 🎨
            </Label>
            <div className="border-2 border-dashed border-purple-200 rounded-lg p-4 text-center hover:border-purple-400 transition-colors relative">
              {coverImageUrl ? (
                <div className="space-y-2">
                  <img src={coverImageUrl} alt="Cover" className="w-full h-20 object-cover rounded" />
                  <p className="text-sm text-green-600">Cover image uploaded!</p>
                  <button
                    type="button"
                    onClick={() => setCoverImagePath('')}
                    className="absolute top-2 right-2 bg-red-500 rounded-full p-1 shadow-lg hover:bg-red-600 transition-colors"
                  >
                    <X className="w-3 h-3 text-white" />
                  </button>
                </div>
              ) : (
                <label className="cursor-pointer block">
                  <Upload className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Click to upload a cover image</p>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleCoverImageUpload}
                    className="hidden"
                    disabled={isUploading}
                  />
                </label>
              )}
            </div>
          </div>

          <div className="flex space-x-3 pt-4">
            <Button
              type="button"
              onClick={onClose}
              variant="outline"
              className="flex-1 border-gray-300 hover:bg-gray-50"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSaving || isUploading || !name.trim()}
              className="flex-1 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white font-semibold shadow-lg"
            >
              {isSaving ? (
                <div className="flex items-center space-x-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>Creating your profile...</span>
                </div>
              ) : (
                'Create My Profile! 🚀'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
