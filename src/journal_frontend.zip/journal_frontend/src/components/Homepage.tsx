import { useGetOwnHomepage } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useNavigate } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Plus, Lock, Globe, Edit, Trash2, Image as ImageIcon } from 'lucide-react';
import { useFileUrl } from '../blob-storage/FileStorage';
import JournalEntryModal from './JournalEntryModal';
import ProfileEditModal from './ProfileEditModal';
import TopNavigation from './TopNavigation';
import { useState, useEffect } from 'react';
import { JournalEntry } from '../backend';
import { useDeleteJournalEntry } from '../hooks/useQueries';

export default function Homepage() {
  console.log('[DEBUG] Homepage: Component mounting');
  
  const navigate = useNavigate();
  const { identity } = useInternetIdentity();
  const { data: homepage, isLoading, error } = useGetOwnHomepage();
  const [showEntryModal, setShowEntryModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [editingEntry, setEditingEntry] = useState<JournalEntry | null>(null);
  const [coverImageError, setCoverImageError] = useState(false);
  const { mutate: deleteEntry } = useDeleteJournalEntry();

  const { data: profilePictureUrl } = useFileUrl(homepage?.profile?.profilePicture || '');
  const { data: coverImageUrl } = useFileUrl(homepage?.profile?.coverImage || '');

  // Debug logging for homepage state
  useEffect(() => {
    console.log('[DEBUG] Homepage: State changed', {
      isLoading,
      hasHomepage: !!homepage,
      hasProfile: !!homepage?.profile,
      entriesCount: homepage?.entries?.length || 0,
      error: error?.message,
      identity: identity?.getPrincipal().toString()
    });
  }, [homepage, isLoading, error, identity]);

  const handleEditEntry = (entry: JournalEntry) => {
    console.log('[DEBUG] Homepage: Edit entry clicked', { entryId: entry.id, title: entry.title });
    setEditingEntry(entry);
    setShowEntryModal(true);
  };

  const handleDeleteEntry = (entryId: string) => {
    console.log('[DEBUG] Homepage: Delete entry clicked', { entryId });
    if (confirm('Are you sure you want to delete this journal entry?')) {
      console.log('[DEBUG] Homepage: Delete confirmed, calling mutation');
      deleteEntry(entryId);
    }
  };

  const handleEntryClick = (entry: JournalEntry) => {
    console.log('[DEBUG] Homepage: Entry clicked', { entryId: entry.id, title: entry.title });
    if (!identity) {
      console.error('[DEBUG] Homepage: No identity available for navigation');
      return;
    }
    
    try {
      const userId = identity.getPrincipal().toString();
      const entryId = entry.id;
      console.log('[DEBUG] Homepage: Navigating to entry detail', { userId, entryId });
      navigate({ to: '/entry/$userId/$entryId', params: { userId, entryId } });
    } catch (error) {
      console.error('[DEBUG] Homepage: Navigation error:', error);
    }
  };

  const handleNewEntry = () => {
    console.log('[DEBUG] Homepage: New entry button clicked');
    navigate({ to: '/add-entry' });
  };

  const handleCoverImageError = () => {
    console.log('[DEBUG] Homepage: Cover image error');
    setCoverImageError(true);
  };

  const formatEntryDate = (date: bigint) => {
    try {
      const formattedDate = new Date(Number(date) / 1000000).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
      console.log('[DEBUG] Homepage: Date formatted', { originalDate: date.toString(), formattedDate });
      return formattedDate;
    } catch (error) {
      console.error('[DEBUG] Homepage: Date formatting error:', error);
      return 'Invalid date';
    }
  };

  const truncateContent = (content: string, maxLength: number = 200) => {
    // Remove markdown image syntax for display
    const contentWithoutImages = content.replace(/!\[.*?\]\(.*?\)/g, '');
    if (contentWithoutImages.length <= maxLength) return contentWithoutImages;
    return contentWithoutImages.substring(0, maxLength) + '...';
  };

  const extractFirstImageUrl = (content: string): string | null => {
    // Extract the first image URL from markdown format: ![alt](url)
    const imageMatch = content.match(/!\[.*?\]\((.*?)\)/);
    return imageMatch ? imageMatch[1] : null;
  };

  if (isLoading) {
    console.log('[DEBUG] Homepage: Showing loading state');
    return (
      <div className="min-h-screen flex flex-col">
        <TopNavigation showShareButton />
        <div className="flex items-center justify-center flex-1">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading your journal...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    console.error('[DEBUG] Homepage: Error state', error);
    return (
      <div className="min-h-screen flex flex-col">
        <TopNavigation showShareButton />
        <div className="flex items-center justify-center flex-1">
          <div className="text-center">
            <p className="text-red-600 mb-4">Error loading your journal: {error.message}</p>
            <Button onClick={() => window.location.reload()}>Retry</Button>
          </div>
        </div>
      </div>
    );
  }

  const profile = homepage?.profile;
  const entries = homepage?.entries || [];

  console.log('[DEBUG] Homepage: Rendering homepage', {
    hasProfile: !!profile,
    profileName: profile?.name,
    entriesCount: entries.length
  });

  return (
    <div className="min-h-screen flex flex-col">
      <TopNavigation showShareButton />

      <div className="container mx-auto px-4 max-w-[1024px] flex-1 pb-8">
        {/* Profile Section */}
        <Card className="mt-8 mb-8 border-0 shadow-xl bg-white/80 backdrop-blur-sm overflow-hidden">
          <div className="relative">
            {coverImageUrl && !coverImageError ? (
              <div className="h-48 bg-gradient-to-r from-purple-400 to-blue-400 relative">
                <img 
                  src={coverImageUrl} 
                  alt="Cover" 
                  className="w-full h-full object-cover" 
                  onError={handleCoverImageError}
                  onLoad={() => {
                    console.log('[DEBUG] Homepage: Cover image loaded successfully');
                    setCoverImageError(false);
                  }}
                />
                <div className="absolute inset-0 bg-black/20"></div>
                <Button
                  onClick={() => {
                    console.log('[DEBUG] Homepage: Edit profile button clicked');
                    setShowProfileModal(true);
                  }}
                  variant="outline"
                  size="sm"
                  className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm border-white/50 hover:bg-white text-gray-700 shadow-lg"
                >
                  <Edit className="w-4 h-4" />
                </Button>
              </div>
            ) : (
              <div className="h-48 bg-gradient-to-r from-purple-400 to-blue-400 relative">
                <div className="absolute inset-0 bg-black/20"></div>
                {coverImageError && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-white/80 text-center">
                      <ImageIcon className="w-12 h-12 mx-auto mb-2 opacity-60" />
                      <p className="text-sm">Cover image unavailable</p>
                    </div>
                  </div>
                )}
                <Button
                  onClick={() => {
                    console.log('[DEBUG] Homepage: Edit profile button clicked (no cover)');
                    setShowProfileModal(true);
                  }}
                  variant="outline"
                  size="sm"
                  className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm border-white/50 hover:bg-white text-gray-700 shadow-lg"
                >
                  <Edit className="w-4 h-4" />
                </Button>
              </div>
            )}
            
            {/* Profile Picture positioned to overlap cover image */}
            <div className="absolute left-6 -bottom-10">
              <Avatar className="w-20 h-20 border-4 border-white shadow-lg">
                <AvatarImage src={profilePictureUrl} />
                <AvatarFallback className="bg-gradient-to-br from-purple-400 to-blue-400 text-white text-2xl font-bold">
                  {profile?.name?.charAt(0).toUpperCase() || '?'}
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
          
          <CardContent className="px-6 pt-12">
            <div className="ml-0">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                {profile?.name || 'Anonymous Writer'}
              </h2>
              {profile?.bio && (
                <p className="text-gray-600 text-lg mb-4">{profile.bio}</p>
              )}
              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <span>{entries.length} journal entries</span>
                <span>{entries.filter(e => e.isPublic).length} public</span>
                <span>{entries.filter(e => !e.isPublic).length} private</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Journal Entries Section */}
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold text-gray-900">My Journal Entries</h3>
          <Button 
            onClick={handleNewEntry}
            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white shadow-lg"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Entry
          </Button>
        </div>

        {entries.length === 0 ? (
          <Card className="border-2 border-dashed border-purple-200 bg-purple-50/50 mb-8">
            <CardContent className="p-12 text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-blue-400 rounded-full flex items-center justify-center mx-auto mb-4">
                <Plus className="w-8 h-8 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-gray-700 mb-2">Start Your Journey!</h4>
              <p className="text-gray-600 mb-6">
                Your journal is empty. Write your first entry and begin capturing your amazing adventures!
              </p>
              <Button 
                onClick={handleNewEntry}
                className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Write First Entry
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6 mb-8">
            {entries
              .sort((a, b) => Number(b.date) - Number(a.date))
              .map((entry) => {
                const firstImageUrl = extractFirstImageUrl(entry.content);
                
                return (
                  <Card 
                    key={entry.id} 
                    className="border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all cursor-pointer group"
                    onClick={() => handleEntryClick(entry)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-xl font-bold text-gray-900 group-hover:text-purple-600 transition-colors mb-2">
                            {entry.title}
                          </CardTitle>
                          <div className="flex items-center space-x-3">
                            <span className="text-sm text-gray-500">
                              {formatEntryDate(entry.date)}
                            </span>
                            <Badge variant={entry.isPublic ? "default" : "secondary"} className="text-xs">
                              {entry.isPublic ? (
                                <>
                                  <Globe className="w-3 h-3 mr-1" />
                                  Public
                                </>
                              ) : (
                                <>
                                  <Lock className="w-3 h-3 mr-1" />
                                  Private
                                </>
                              )}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2 opacity-0 group-hover:opacity-100 transition-opacity ml-4">
                          <Button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEditEntry(entry);
                            }}
                            variant="ghost"
                            size="sm"
                            className="text-gray-500 hover:text-purple-600"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteEntry(entry.id);
                            }}
                            variant="ghost"
                            size="sm"
                            className="text-gray-500 hover:text-red-600"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="flex gap-4">
                        {/* Image thumbnail */}
                        {firstImageUrl && (
                          <div className="flex-shrink-0">
                            <img 
                              src={firstImageUrl} 
                              alt="Entry preview" 
                              className="w-20 h-20 object-cover rounded-lg shadow-sm border border-gray-200"
                              onError={(e) => {
                                console.log('[DEBUG] Homepage: Entry image failed to load');
                                // Hide image if it fails to load
                                e.currentTarget.style.display = 'none';
                              }}
                            />
                          </div>
                        )}
                        
                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <p className="text-gray-700 leading-relaxed">
                            {truncateContent(entry.content)}
                          </p>
                          {entry.content.length > 200 && (
                            <p className="text-purple-600 text-sm mt-2 font-medium">
                              Click to read more...
                            </p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
          </div>
        )}
      </div>

      {/* Modals */}
      {showEntryModal && (
        <JournalEntryModal
          entry={editingEntry}
          onClose={() => {
            console.log('[DEBUG] Homepage: Entry modal closed');
            setShowEntryModal(false);
            setEditingEntry(null);
          }}
        />
      )}

      {showProfileModal && (
        <ProfileEditModal
          onClose={() => {
            console.log('[DEBUG] Homepage: Profile modal closed');
            setShowProfileModal(false);
          }}
        />
      )}
    </div>
  );
}
