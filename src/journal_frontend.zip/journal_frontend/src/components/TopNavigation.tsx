import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { LogOut, Share2 } from 'lucide-react';
import { toast } from 'sonner';
import DooLogo from './DooLogo';

interface TopNavigationProps {
  showShareButton?: boolean;
  onShare?: () => void;
}

export default function TopNavigation({ showShareButton = false, onShare }: TopNavigationProps) {
  const { clear, identity } = useInternetIdentity();
  const queryClient = useQueryClient();

  const handleLogout = async () => {
    await clear();
    queryClient.clear();
  };

  const handleShare = () => {
    if (onShare) {
      onShare();
    } else if (identity) {
      const shareUrl = `${window.location.origin}?user=${identity.getPrincipal().toString()}`;
      navigator.clipboard.writeText(shareUrl).then(() => {
        toast.success('Profile link copied to clipboard!');
      }).catch(() => {
        toast.error('Failed to copy link');
      });
    }
  };

  return (
    <header className="bg-white/80 backdrop-blur-sm border-b border-purple-200 sticky top-0 z-40">
      <div className="container mx-auto px-4 py-4 max-w-[1024px]">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <DooLogo width={40} height={40} />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              My Journal
            </h1>
          </div>
          <div className="flex items-center space-x-2">
            {showShareButton && (
              <Button
                onClick={handleShare}
                variant="outline"
                size="sm"
                className="border-purple-200 hover:bg-purple-50"
              >
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
            )}
            <Button
              onClick={handleLogout}
              variant="outline"
              size="sm"
              className="border-red-200 hover:bg-red-50 text-red-600"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
